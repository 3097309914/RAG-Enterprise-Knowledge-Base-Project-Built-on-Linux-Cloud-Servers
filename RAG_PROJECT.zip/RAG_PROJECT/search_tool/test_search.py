import sys
from pathlib import Path

# __file__ = test_load/demo6.py
current_file = Path(__file__)
# parent → test_load，parent.parent → RAG_PROJECT（项目根目录！）
root_dir = current_file.parent.parent
sys.path.append(str(root_dir))
print("项目根目录已加入sys.path：", root_dir)

from langchain_milvus import Milvus, BM25BuiltInFunction
from pymilvus import MilvusClient, DataType, Function, FunctionType, AnnSearchRequest, RRFRanker

from documents.markdown_parser import MarkdownParser
from documents.milvus_db import MilvusVectorSave
from llm_models.embeddings_model import bge_embedding
from utils.env_utils import MILVUS_URI, COLLECTION_NAME


def test1():
    # 第一种
    mv = MilvusVectorSave()
    mv.create_connection()
    # result = mv.vector_store_saved.similarity_search(
    result = mv.vector_store_saved.similarity_search_with_score(
        query='现在，最先进的纳米级清洗技术是什么？', # 先是相似性检索
        k=2,
        expr='category == "content"' # 最后是过滤检索，过滤出 category == "Title" 的文档,整数字符串，模糊匹配
    )
    # similarity_search_with_score：返回的是一个二元组的列表，二元组中第二个值：相似度分数
    for doc in result:
        print(doc)


def test2():
    """创建一个新的collection全文检索 中文不能使用英文的enable_analyzer分词器 必须使用中文的jieba分词器"""
    client = MilvusClient(uri=MILVUS_URI)

    schema = client.create_schema()
    schema.add_field(field_name='id', datatype=DataType.INT64, is_primary=True, auto_id=True)
    schema.add_field(field_name='text', datatype=DataType.VARCHAR, max_length=6000, enable_analyzer=True,
                     analyzer_params={"tokenizer": "jieba", "filter": ["cnalphanumonly"]}) 
    # 中文为主的分词器 enable_analyzer=True并且analyzer_params={"tokenizer": "jieba"},英文分词器就只需要enable_analyzer=True即可
    # schema.add_field(field_name='text', datatype=DataType.VARCHAR, max_length=6000, enable_analyzer=True)
    schema.add_field(field_name='category', datatype=DataType.VARCHAR, max_length=1000)
    schema.add_field(field_name='sparse', datatype=DataType.SPARSE_FLOAT_VECTOR)

    bm25_function = Function(
        name="text_bm25_emb",  # Function name
        input_field_names=["text"],  # Name of the VARCHAR field containing raw text data
        output_field_names=["sparse"],  # Name of the SPARSE_FLOAT_VECTOR field reserved to store generated embeddings
        function_type=FunctionType.BM25,  # Set to `BM25`
    )
    schema.add_function(bm25_function)
    index_params = client.prepare_index_params()

    index_params.add_index(
        field_name="sparse",
        index_name="sparse_inverted_index",
        index_type="SPARSE_INVERTED_INDEX",  # Inverted index type for sparse vectors
        metric_type="BM25",
        params={
            "inverted_index_algo": "DAAT_MAXSCORE",
            # Algorithm for building and querying the index. Valid values: DAAT_MAXSCORE, DAAT_WAND, TAAT_NAIVE.
            "bm25_k1": 1.2,
            "bm25_b": 0.75
        },
    )

    if 'demo' in client.list_collections():
        # 先释放， 再删除索引，再删除collection
        client.release_collection(collection_name='demo')
        client.drop_index(collection_name='demo', index_name='sparse_inverted_index')
        # client.drop_index(collection_name='demo', index_name='dense_inverted_index')
        client.drop_collection(collection_name='demo')

    client.create_collection(
        collection_name='demo',
        schema=schema,
        index_params=index_params
    )


def test3():
    """往collection中插入数据 先加载VectorStore，再调用add_documents()方法"""
    vector_store = Milvus(
        embedding_function=None,
        collection_name='demo',
        builtin_function=BM25BuiltInFunction(output_field_names='sparse'),
        vector_field=['sparse'],
        consistency_level="Strong",
        auto_id=True,
        connection_args={"uri": MILVUS_URI}
    )

    # 解析文件内容
    file_path = r'G:\AI Large Language Model\马士兵 AI 实战大模型项目\RAG企业知识库项目\RAG_PROJECT\datas\md\tech_report_0tfhhamx.md'
    parser = MarkdownParser()
    docs = parser.parse_markdown_to_documents(file_path)

    vector_store.add_documents(docs)


def test4():
    """全文搜索测试"""
    vector_store = Milvus(
        embedding_function=None,
        collection_name='demo',
        builtin_function=BM25BuiltInFunction(output_field_names='sparse'),
        vector_field=['sparse'],
        consistency_level="Strong",
        auto_id=True,
        connection_args={"uri": MILVUS_URI}
    )

    res = vector_store.similarity_search_with_score(
        query='活性氧原子',
        k=2
    )

    for doc in res: # 打印每个搜索结果的文档内容
        print(doc)


def test5():
    """采用云服务器的PyMilvus的库来进行检索 不采用test4中的langchain_milvus中的Milvus来进行检索了"""
    client = MilvusClient(uri=MILVUS_URI)
    res = client.search(
        collection_name='demo',
        data=['半导体表面特征改善'],
        anns_field='sparse',
        limit=3,
        output_fields=['text', 'id', 'category'],
        search_params={"params": {'drop_ratio_search': 0.2}} # 搜索时要忽略的低重要性词语的比例。
    )
    for item in res[0]:
        print(item)

def test6():
    client = MilvusClient(uri=MILVUS_URI)
    result = client.query(
        collection_name=COLLECTION_NAME,
        filter="category == 'Title'",  # 查询 category == 'Title' 的所有数据
        output_fields=['text', 'category', 'filename'],  # 指定返回的字段
    )

    print('测试 过滤查询的结果是: ', result)


def test7():
    """云服务器的pymilvus的混合检索"""
    client = MilvusClient(uri=MILVUS_URI)
    # data需要传入向量 bge_embedding.embed_query(text:str) 来生成查询向量, anns_field指定使用哪个向量字段进行搜索
    # param表示使用什么方式进行搜索，dense使用内积(IP)进行向量相似度计算，sparse使用BM25进行文本相似度计算，nprobe提高搜索精度
    # print(bge_embedding.embed_query('现在，最先进的纳米级清洗技术是什么？'))
    search_params_1 = {
        'data': [bge_embedding.embed_query('现在，最先进的纳米级清洗技术是什么？')], # 二维数组
        'anns_field': 'dense',
        "param": {
            "metric_type": "IP",
            "params": {"nprobe": 10}
        },
        "limit": 5
    }
    req1 = AnnSearchRequest(**search_params_1)  # dense密集向量搜索请求对象，传入字典数据，要进行检索的参数或条件
    # milvus使用内置的（稀疏嵌入）BM25算法将字符串转换为稀疏向量进行文本相似度计算
    # param表示使用什么方式进行搜索，sparse使用BM25进行文本相似度计算
    search_params_2 = {
        'data': ['纳米级清洗技术是什么？'],
        'anns_field': 'sparse',
        "param": {
            "metric_type": "BM25"
        },
        "limit": 5
    }
    req2 = AnnSearchRequest(**search_params_2)  # sparse稀疏向量搜索请求对象
    # ranker表示使用的排序器，这里使用RRFRanker(60)进行结果重排序
    res = client.hybrid_search(
        collection_name=COLLECTION_NAME, # 表的名称
        reqs=[req1, req2], # 搜索请求对象的数组list，多个不同的搜索请求，每一个搜索请求对象都是一个AnnSearchRequest
        ranker=RRFRanker(60),
        limit=5,
        output_fields=['text', 'title', 'category']
    )
    # 两种或者三种的不同的搜索都搜到这个结果，那么这个结果一定会被优先排在最前面。
    # 假设，通过同一关键词对同一句话，根据密集向量搜索搜到的结果一个documentid=1，
    # 然后通过稀疏向量搜索又搜到的结果一个documentid=1。这个documentid会被排到前面。
    # 两个结果
    for hits in res:
        print('topN的 结果：')
        for item in hits:
            print(item)


def test8():
    """使用langchain对Milvus进行混合检索"""
    mv = MilvusVectorSave()
    mv.create_connection()
    res = mv.vector_store_saved.similarity_search(
        query='现在，最先进的纳米级清洗技术是什么？',
        k=3, # 最多返回 3 个数据
        ranker_type='rrf',  # ranker_type='weighted' 加权平均
        ranker_params={"k": 100}, # 传入k值
    )

    for item in res:
        print(item)


def test9():
    """使用langchain对Milvus进行混合检索"""
    mv = MilvusVectorSave()
    mv.create_connection()
    # res = mv.vector_store_saved.similarity_search_with_score(
    #     query='现在，最先进的纳米级清洗技术是什么？',
    #     k=3,
    #     ranker_type='rrf',  # ranker_type='weighted'
    #     ranker_params={"k": 100},
    # )
    # 如果使用as_retriever来检索得到一个检索器retriever对象，可以通过invoke方法进行查询
    retriever = mv.vector_store_saved.as_retriever(
        search_type='similarity',  # 仅返回相似度超过阈值的文档 similarity
        search_kwargs={
            "k": 3,
            "score_threshold": 0.1,
            "ranker_type": "rrf",
            "ranker_params": {"k": 100},
            'filter': {"category": "content"} # 加入过滤检索
        }
    )

    res = retriever.invoke('介绍一下：光刻机有哪几种？') # 使用检索器进行查询返回list

    for item in res:
        print(item)

if __name__ == '__main__':
    # test1()  # 测试相似性检索 + 过滤检索
    # test2()  # 创建表结构，全文检索，中文的分词器
    # test3()  # 插入数据
    # test4()  # 使用langchain_milvus中的Milvus测试全文检索
    # test5()  # 使用云服务器的PyMilvus的库测试全文检索
    # test6() # 测试创建表格和混合解析后创建连接，检索query后的结果，全文检索的结果，
    # 插入一条新数据，需要等待数据生效后才可以查询query的结果
    # test7() # PyMilvus的MilvusClient混合检索
    # test8() # langchain对Milvus进行混合检索
    test9() # 使用langchain对Milvus进行相似性检索并带过滤条件，返回符合条件的结果

    # docker run -d -p 8000:3000 -e MILVUS_URL=192.168.0.90:19530 zilliz/attu:v2.5
    # sudo docker start milvus-standalone
    # source ./activate  