import sys
from pathlib import Path

# __file__ = test_load/demo6.py
current_file = Path(__file__)
# parent → test_load，parent.parent → RAG_PROJECT（项目根目录！）
root_dir = current_file.parent.parent
sys.path.append(str(root_dir))
print("项目根目录已加入sys.path：", root_dir)
# from langchain.agents import create_tool_calling_agent, AgentExecutor
from langchain_classic.agents import create_tool_calling_agent, AgentExecutor
from langchain_core.chat_history import BaseChatMessageHistory
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.runnables import RunnableWithMessageHistory
from langchain_core.tools import create_retriever_tool
from langchain_community.chat_message_histories import ChatMessageHistory
from documents.milvus_db import MilvusVectorSave
from llm_models.all_llm import llm
from tools.retriever_tools import retriever_tool

# 提示词模板， 系统角色，对话历史输入MessagesPlaceholder，以及用户输入human和agent_scratchpad智能体推理的便利贴
prompt = ChatPromptTemplate.from_messages([
    ('system', '你是一个智能助手，尽可能的调用工具回答用户的问题'),
    MessagesPlaceholder(variable_name='chat_history', optional=True),
    ('human', '{input}'),
    MessagesPlaceholder(variable_name='agent_scratchpad', optional=True),
])

# tools.retriever_tools中定义的retriever_tool使用的是Milvus向量数据库的检索工具
agent = create_tool_calling_agent(llm, [retriever_tool], prompt)
# Langchain中唯一支持智能体的只有一个类是AgentExecutor，其他的都是工具类，智能体类，都是抽象类
executor = AgentExecutor(agent=agent, tools=[retriever_tool])

# resp1 = executor.invoke({'input': '什么是EUV光刻机？'})
# print(resp1)

store = {}

def get_session_history(session_id: str) -> BaseChatMessageHistory:
    if session_id not in store:
        store[session_id] = ChatMessageHistory()
    return store[session_id]

# 提示词prompt的chat_history，传入四个参数，智能体的executor，历史的函数get_session_history，输入消息的key，历史消息的key
agent_with_history = RunnableWithMessageHistory(
    executor,
    get_session_history,
    input_messages_key='input',
    history_messages_key='chat_history'
)

resp2 = agent_with_history.invoke(
    {'input': '什么是EUV光刻机？'},
    config={'configurable': {"session_id": 'zs123'}}
)

print(resp2)

# resp3 = agent_with_history.invoke(
#     {'input': '什么是光刻机？'},
#     config={'configurable': {"session_id": 'zs123'}}
# )

# print(resp3)
