import os

from dotenv import load_dotenv

load_dotenv(override=True)

# OPENAI_API_KEY = "sk-ie6zdD00QM05lMjvAb44A2Cc9a35496dA30dA9E1Dd0c1168" 
OPENAI_API_KEY = os.getenv('OPENAI_API_KEY')
DEEPSEEK_API_KEY = os.getenv('DEEPSEEK_API_KEY')
os.environ["TAVILY_API_KEY"]="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"
MILVUS_URI = 'http://60.204.251.3:19530'  

COLLECTION_NAME = 't_collection01'
