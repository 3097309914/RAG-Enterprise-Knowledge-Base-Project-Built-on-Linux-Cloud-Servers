import nltk
# 设置国内镜像
nltk.download('punkt', download_dir=r'C:\Users\Li\miniconda3\envs\yolo26\nltk_data')
nltk.download('averaged_perceptron_tagger', download_dir=r'C:\Users\Li\miniconda3\envs\yolo26\nltk_data')

from langchain_community.document_loaders import UnstructuredMarkdownLoader

loader = UnstructuredMarkdownLoader(
    file_path=r'G:\AI Large Language Model\马士兵 AI 实战大模型项目\RAG企业知识库项目\RAG_PROJECT\datas\md\operational_faq.md',
    mode='elements',
    strategy='fast'
)
docs = loader.load()
print(f'doc的数量是: {len(docs)}')
for i in range(min(10, len(docs))):
    print(docs[i].metadata)
    print(docs[i].page_content)
    print('--' * 50)
