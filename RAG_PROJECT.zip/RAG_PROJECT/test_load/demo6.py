# from openai import OpenAI

# client = OpenAI(
#     base_url="https://tokken.cc/v1",
#     api_key="sk-MWLSpDmAqHzKsEUyKICzwT7GiMNBMc9WQAEacNtZ0cmjUVhL",
# )

# completion = client.chat.completions.create(
#     model="gpt-5.5",
#     messages=[
#         {"role": "user", "content": "Explain quantum entanglement in one paragraph."}
#     ],
# )

# print(completion.choices[0].message.content)

# from langchain_openai import OpenAIEmbeddings


# openai_embedding = OpenAIEmbeddings(
#     openai_api_key="sk-MWLSpDmAqHzKsEUyKICzwT7GiMNBMc9WQAEacNtZ0cmjUVhL",
#     openai_api_base="https://tokken.cc/v1",
#     model="text-embedding-ada-002"
# )
# print(openai_embedding)

# # 新增：真实调用嵌入接口，触发网络请求，没有这个text-embedding-ada-002模型
# res = openai_embedding.embed_query("测试文本")
# print("向量长度：", len(res))


# import os
# from dotenv import load_dotenv
# load_dotenv(override=True)

# # API易 Embedding
# from langchain_openai import OpenAIEmbeddings
# openai_embedding = OpenAIEmbeddings(
#     openai_api_key="sk-ie6zdD00QM05lMjvAb44A2Cc9a35496dA30dA9E1Dd0c1168",
#     openai_api_base="https://api.apiyi.com/v1",
#     model="text-embedding-ada-002"
# )

# res = openai_embedding.embed_query("测试文本")
# print("向量长度：", len(res))


# # 本地BGE（保留，备用）
# from langchain_huggingface import HuggingFaceEmbeddings
# model_name = "BAAI/bge-small-zh-v1.5"
# model_kwargs = {"device": "cpu"}
# encode_kwargs = {"normalize_embeddings": True}
# bge_embedding = HuggingFaceEmbeddings(
#     model_name=model_name, model_kwargs=model_kwargs, encode_kwargs=encode_kwargs
# )

from openai import OpenAI
client = OpenAI(
    api_key="sk-ie6zdD00QM05lMjvAb44A2Cc9a35496dA30dA9E1Dd0c1168",
    base_url="https://api.apiyi.com/v1"
)

# 【向量接口，用来生成embedding】
resp = client.embeddings.create(
    input="测试文本123456",
    model="text-embedding-ada-002"
)
print("向量维度：", len(resp.data[0].embedding))


{"_type":"newapi_channel_conn","key":"sk-MWLSpDmAqHzKsEUyKICzwT7GiMNBMc9WQAEacNtZ0cmjUVhL",
 "url":"https://tokken.cc"}