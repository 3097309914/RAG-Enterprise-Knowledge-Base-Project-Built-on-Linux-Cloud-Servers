from langchain_community.document_loaders import PyPDFLoader

pdf_file = r'G:\AI Large Language Model\马士兵 AI 实战大模型项目\RAG企业知识库项目\RAG_PROJECT\datas\layout-parser-paper.pdf'

# 一页一页的解析，每一页对于一个document对象
loader = PyPDFLoader(file_path=pdf_file)

docs = loader.load()



print(f'doc的数量是: {len(docs)}')
print(docs[0].metadata)
print(docs[0].page_content)