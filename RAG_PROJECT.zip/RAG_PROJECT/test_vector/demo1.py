import sys
from pathlib import Path

# __file__ = test_load/demo6.py
current_file = Path(__file__)
# parent → test_load，parent.parent → RAG_PROJECT（项目根目录！）
root_dir = current_file.parent.parent
sys.path.append(str(root_dir))
print("项目根目录已加入sys.path：", root_dir)
from llm_models.embeddings_model import bge_embedding


# sentence_transformers

embeddings = bge_embedding.embed_documents(
    [
        "Hi there!",
        "Oh, hello!",
        "What's your name?",
        "My friends call me World",
        "Hello World!"
    ]
)  
print(len(embeddings), len(embeddings[0]))

embedded_query = bge_embedding.embed_query("What was the name mentioned in the conversation?")
print(embedded_query)